#!/usr/bin/env sh

echo "Please install Python 2 packages cryptography, bcrypt, and pynacl if they are not already installed. Recommend installing through pip."
