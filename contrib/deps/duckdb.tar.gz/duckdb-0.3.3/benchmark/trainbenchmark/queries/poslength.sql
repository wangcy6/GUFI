SELECT
	id AS segment,
	length AS length
FROM Segment
WHERE length <= 0;
